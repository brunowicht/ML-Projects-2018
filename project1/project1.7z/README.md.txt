## Project 1 for machine learning 
- To run use the file run.py if you want to modify the path where the test.csv and train.csv files are. 
- The main run method uses the perceptron with a bagging 100 , 250000 iterations, a gamma of 1e-6
- The output will generate a plot of the features sorted by weights to visualize how some features are more important. 
- 